package value

trait Value {

}
